import React from 'react'

export default function Trans() {
    return (
        <div>This is the transaction page</div>
    )
}
